# Teams Meeting - Moodle Activity Module (PNA/CORS Safe)

Microsoft Teams toplantı entegrasyonu sağlayan Moodle etkinlik modülü. `mod_msteams` eklentisinin **Chrome'da çalışmama sorununu** çözen alternatif.

## Problem

Mevcut [`mod_msteams`](https://moodle.org/plugins/mod_msteams) eklentisi, Enovation toplantı uygulamasını (`https://www.enovation.ie/msteams/`) bir **iframe** içinde yükler. Bu yaklaşım üniversite/kurumsal ağlarda **Chrome'da çalışmaz**:

- **PNA (Private Network Access)**: Chrome, iframe'ler aracılığıyla farklı ağ bölgeleri arasındaki iletişimi kısıtlar
- **Third-party Cookies**: Chrome, iframe içindeki üçüncü taraf çerezleri engeller. Microsoft OAuth login çerezlere ihtiyaç duyar
- **CORS**: Cross-origin iletişim kısıtlamaları postMessage akışını bozabilir

Plugin yorumlarında aynı sorunlar görülüyor:
> "Does anyone seen CORS block error when creating live session link in moodle 5.1.1?"

## Çözüm: Popup Window Yaklaşımı

Bu eklenti iframe **yerine** popup pencere kullanır:

```
Moodle Formu (parent)
    │
    ├── "Toplantı Oluştur" butonuna tıkla
    │
    └── window.open() → Popup Pencere (popup.php - Moodle sunucusundan)
                             │
                             ├── <iframe> → Enovation Meeting App
                             │                  │
                             │                  └── Toplantı oluştur
                             │                  └── window.parent.postMessage(url)
                             │                           ↓
                             ├── postMessage'ı yakala
                             └── window.opener.postMessage(url)
                                          ↓
                              Moodle Formu URL'yi alır
```

**Neden çalışır:**
1. Popup pencere **top-level browsing context**'tir
2. İçindeki iframe **first-party** statüsündedir (çerezler çalışır)
3. Microsoft OAuth login normal çalışır
4. postMessage ağ isteği değildir, PNA'dan etkilenmez
5. Her tarayıcıda çalışır: Chrome, Firefox, Safari, Edge

## Uyumluluk

| Gereksinim | Versiyon |
|---|---|
| Moodle | 4.5+ / 5.x (5.1.1 test edildi) |
| PHP | 8.1+ |
| Tarayıcı | Chrome, Firefox, Safari, Edge (tümü) |

## Kurulum

### 1. Dosyaları Kopyalama

```bash
cp -r mod/teamsmeeting /path/to/moodle/mod/teamsmeeting
```

### 2. Moodle'da Kurulum

1. Admin olarak giriş yapın
2. **Site Administration > Notifications** sayfasına gidin
3. Eklenti algılanacak, "Upgrade" tıklayın

### 3. Ayarlar (Opsiyonel)

**Site Administration > Plugins > Activity modules > Teams Meeting**

| Ayar | Açıklama | Varsayılan |
|---|---|---|
| Meeting App URL | Enovation toplantı uygulaması URL'si | `https://enomsteams.z16.web.core.windows.net` |
| Open in New Tab | Öğrenciler için toplantı linki yeni sekmede açılsın | Evet |

> **Not:** Enovation'ın eski URL'si (`https://www.enovation.ie/msteams/`) de çalışır, ancak SSL sertifika sorunları yaşanabilir. Yeni URL önerilir.

## Kullanım

### Eğitmenler İçin

1. Derse girin > **Turn editing on** > **Add an activity** > **Teams Meeting**
2. Toplantı adını girin
3. **"Teams Toplantısı Oluştur"** butonuna tıklayın
4. Popup pencerede Microsoft hesabınızla oturum açın
5. Toplantıyı oluşturun
6. URL otomatik olarak yakalanır ve forma yerleştirilir
7. **Save** butonuna tıklayın

> **Alternatif:** "Manuel girin" linkine tıklayarak toplantı URL'sini elle de yapıştırabilirsiniz.

### Öğrenciler İçin

1. Dersteki Teams Toplantısı etkinliğine tıklayın
2. **"Teams Toplantısına Katıl"** butonuna tıklayın
3. Yeni sekmede Teams açılır

## mod_msteams ile Karşılaştırma

| Özellik | mod_msteams | Bu Eklenti (mod_teamsmeeting) |
|---|---|---|
| Toplantı oluşturma | iframe içinde | Popup pencerede |
| Chrome uyumu | PNA/Cookie sorunları | Sorunsuz çalışır |
| Üniversite ağı | Sorunlu | Sorunsuz |
| Enovation app | Destekler | Destekler (aynı URL) |
| Manuel URL girişi | Yok | Var (fallback) |
| tiny_teamsmeeting gerekli mi? | Evet (5.0+) | Hayır |
| Moodle 5.1.1 | Sorunlu | Uyumlu |

## Dosya Yapısı

```
mod/teamsmeeting/
├── version.php              # Versiyon bilgisi
├── lib.php                  # Temel fonksiyonlar
├── mod_form.php             # Etkinlik formu (popup + postMessage)
├── popup.php                # Relay sayfası (PNA bypass mekanizması)
├── view.php                 # Öğrenci görüntüleme sayfası
├── index.php                # Ders modülleri listesi
├── settings.php             # Admin ayarları
├── styles.css               # CSS
├── classes/
│   ├── privacy/provider.php # GDPR
│   └── event/               # Olaylar
├── db/
│   ├── install.xml          # Veritabanı şeması
│   └── access.php           # Yetkiler
├── backup/moodle2/          # Yedekleme/geri yükleme
├── lang/
│   ├── en/teamsmeeting.php  # İngilizce
│   └── tr/teamsmeeting.php  # Türkçe
└── pix/                     # İkonlar
```

## Sorun Giderme

### Popup pencere engelleniyorsa
Tarayıcının popup engelleyicisi devre dışı bırakılmalı veya Moodle sitesi için izin verilmeli.

### URL otomatik yakalanamıyorsa
"URL yakalanamadı mı?" butonuna tıklayıp toplantı URL'sini manuel yapıştırın.

### Enovation uygulaması yüklenmiyorsa
Admin ayarlarından Meeting App URL'sini kontrol edin. Yeni URL: `https://enomsteams.z16.web.core.windows.net`

## Lisans

GNU GPL v3 veya üstü - [Lisans metni](http://www.gnu.org/copyleft/gpl.html)
